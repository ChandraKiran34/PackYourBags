// UserWish.js

import React from 'react';

function UserWish() {
  return (
    <div>
      {/* Content for the UserWish  */}
      <h2>User Wish </h2>
      {/* Add your content here */}
    </div>
  );
}

export default UserWish;
